//
// Created by hh on 2025/5/30.
//

//#include <i2c.h>
#include <IIC_BSP.h>
#include "MPU9250.h"
#include "stm32f1xx_hal.h"
/*
 * acc_gry.c
 *
 *  Created on: Jan 22, 2024
 *      Author: smile
 */

//#include "acc_gry.h"
#include "IIC_bus.h"
#include "imu_9.h"
#include "in_flash.h"

//reg_cfg_t acc_gyro_init_reg[20] =
//        {
//                { CTRL3_C, 0x01 },
//                { CTRL3_C, 0x44 },
//                { CTRL1_XL, ODR_1660HZ | ACC_SCALE_2g | 0x02 },
//                { CTRL8_XL, 0xa8 },
//                { CTRL2_G, ODR_1660HZ | GRY_SCALE_500},
//        };






//初始化MPU9250
//返回值:0,成功
//    其他,错误代码
uint8_t MPU_9250_Init(void) {
    uint8_t res = 0;
    IIC_Init();     //初始化IIC总线
    MPU_Write_Byte(MPU9250_ADDR, MPU_PWR_MGMT1_REG, 0X80);//复位MPU9250
    HAL_Delay(100);  //延时100ms
    MPU_Write_Byte(MPU9250_ADDR, MPU_PWR_MGMT1_REG, 0X00);//唤醒MPU9250
    MPU_Set_Gyro_Fsr(1);                                //陀螺仪传感器,±2000dps
    MPU_Set_Accel_Fsr(0);                                //加速度传感器,±2g
    MPU_Set_Rate(50);                                    //设置采样率50Hz
    MPU_Write_Byte(MPU9250_ADDR, MPU_INT_EN_REG, 0X00);   //关闭所有中断
    MPU_Write_Byte(MPU9250_ADDR, MPU_USER_CTRL_REG, 0X00);//I2C主模式关闭
    MPU_Write_Byte(MPU9250_ADDR, MPU_FIFO_EN_REG, 0X00);    //关闭FIFO
    MPU_Write_Byte(MPU9250_ADDR, MPU_INTBP_CFG_REG, 0X02);//INT引脚低电平有效，开启bypass模式，可以直接读取磁力计
    res = MPU_Read_Byte(MPU9250_ADDR, MPU_DEVICE_ID_REG);  //读取MPU6500的ID
    if (res == MPU6500_ID) //器件ID正确
    {
        MPU_Write_Byte(MPU9250_ADDR, MPU_PWR_MGMT1_REG, 0X01);    //设置CLKSEL,PLL X轴为参考
        MPU_Write_Byte(MPU9250_ADDR, MPU_PWR_MGMT2_REG, 0X00);    //加速度与陀螺仪都工作
        MPU_Set_Rate(50);                                //设置采样率为50Hz
    } else return 1;
    HAL_Delay(100);  //延时100ms
    res = MPU_Read_Byte(AK8963_ADDR, MAG_WIA);                //读取AK8963 ID
    if (res == AK8963_ID) {
        MPU_Write_Byte(AK8963_ADDR, MAG_CNTL1, 0X11);        //设置AK8963为单次测量模式
    } else return 1;

    return 0;
}


//设置MPU9250陀螺仪传感器满量程范围
//fsr:0,±250dps;1,±500dps;2,±1000dps;3,±2000dps
//返回值:0,设置成功
//    其他,设置失败
uint8_t MPU_Set_Gyro_Fsr(uint8_t fsr) {
    return MPU_Write_Byte(MPU9250_ADDR, MPU_GYRO_CFG_REG, fsr << 3);//设置陀螺仪满量程范围
}

//设置MPU9250加速度传感器满量程范围
//fsr:0,±2g;1,±4g;2,±8g;3,±16g
//返回值:0,设置成功
//    其他,设置失败
uint8_t MPU_Set_Accel_Fsr(uint8_t fsr) {
    return MPU_Write_Byte(MPU9250_ADDR, MPU_ACCEL_CFG_REG, fsr << 3);//设置加速度传感器满量程范围
}

//设置MPU9250的数字低通滤波器
//lpf:数字低通滤波频率(Hz)
//返回值:0,设置成功
//    其他,设置失败
uint8_t MPU_Set_LPF(uint16_t lpf) {
    uint8_t data = 0;
    if (lpf >= 188)data = 1;
    else if (lpf >= 98)data = 2;
    else if (lpf >= 42)data = 3;
    else if (lpf >= 20)data = 4;
    else if (lpf >= 10)data = 5;
    else data = 6;
    return MPU_Write_Byte(MPU9250_ADDR, MPU_CFG_REG, data);//设置数字低通滤波器
}

//设置MPU9250的采样率(假定Fs=1KHz)
//rate:4~1000(Hz)
//返回值:0,设置成功
//    其他,设置失败
uint8_t MPU_Set_Rate(uint16_t rate) {
    uint8_t data;
    if (rate > 1000)rate = 1000;
    if (rate < 4)rate = 4;
    data = 1000 / rate - 1;
    data = MPU_Write_Byte(MPU9250_ADDR, MPU_SAMPLE_RATE_REG, data);    //设置数字低通滤波器
    return MPU_Set_LPF(rate / 2);    //自动设置LPF为采样率的一半
}

//得到温度值
//返回值:温度值(扩大了100倍)
short MPU_Get_Temperature(void) {
    uint8_t buf[2];
    short raw;
    float temp;
    MPU_Read_Len(MPU9250_ADDR, MPU_TEMP_OUTH_REG, 2, buf);
    raw = ((uint16_t) buf[0] << 8) | buf[1];
    temp = 21 + ((double) raw) / 333.87;
    return temp * 100;;
}

//得到陀螺仪值(原始值)
//gx,gy,gz:陀螺仪x,y,z轴的原始读数(带符号)
//返回值:0,成功
//    其他,错误代码
uint8_t MPU_Get_Gyroscope(short *gx, short *gy, short *gz) {
    uint8_t buf[6], res;
    res = MPU_Read_Len(MPU9250_ADDR, MPU_GYRO_XOUTH_REG, 6, buf);
    if (res == 0) {
        *gx = ((uint16_t) buf[0] << 8) | buf[1];
        *gy = ((uint16_t) buf[2] << 8) | buf[3];
        *gz = ((uint16_t) buf[4] << 8) | buf[5];
    }
    return res;;
}

//得到加速度值(原始值)
//gx,gy,gz:陀螺仪x,y,z轴的原始读数(带符号)
//返回值:0,成功
//    其他,错误代码
uint8_t MPU_Get_Accelerometer(short *ax, short *ay, short *az) {
    uint8_t buf[6], res;
    res = MPU_Read_Len(MPU9250_ADDR, MPU_ACCEL_XOUTH_REG, 6, buf);
    if (res == 0) {
        *ax = ((uint16_t) buf[0] << 8) | buf[1];
        *ay = ((uint16_t) buf[2] << 8) | buf[3];
        *az = ((uint16_t) buf[4] << 8) | buf[5];
    }
    return res;;
}

//得到磁力计值(原始值)
//mx,my,mz:磁力计x,y,z轴的原始读数(带符号)
//返回值:0,成功
//    其他,错误代码
uint8_t MPU_Get_Magnetometer(short *mx, short *my, short *mz) {
    uint8_t buf[6], res;
    res = MPU_Read_Len(AK8963_ADDR, MAG_XOUT_L, 6, buf);
    if (res == 0) {
        *mx = ((uint16_t) buf[1] << 8) | buf[0];
        *my = ((uint16_t) buf[3] << 8) | buf[2];
        *mz = ((uint16_t) buf[5] << 8) | buf[4];
    }
    MPU_Write_Byte(AK8963_ADDR, MAG_CNTL1, 0X11); //AK8963每次读完以后都需要重新设置为单次测量模式
    return res;;
}

//IIC连续写
//addr:器件地址
//reg:寄存器地址
//len:写入长度
//buf:数据区
//返回值:0,正常
//    其他,错误代码
uint8_t MPU_Write_Len(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *buf) {
    uint8_t i;
    BSP_IIC_Start();
    BSP_IIC_Send_Byte((addr << 1) | 0); //发送器件地址+写命令
    if (BSP_IIC_Wait_Ack())          //等待应答
    {
        BSP_IIC_Stop();
        return 1;
    }
    BSP_IIC_Send_Byte(reg);         //写寄存器地址
    BSP_IIC_Wait_Ack();             //等待应答
    for (i = 0; i < len; i++) {
        BSP_IIC_Send_Byte(buf[i]);  //发送数据
        if (BSP_IIC_Wait_Ack())      //等待ACK
        {
            BSP_IIC_Stop();
            return 1;
        }
    }
    BSP_IIC_Stop();
    return 0;
}

/**
 * @brief 从I2C设备连续读取多个寄存器数据
 * @param addr: I2C设备的7位地址
 * @param RegAddress: 起始寄存器地址
 * @param count: 要读取的数据字节数
 * @param DataBuffer: 存储读取数据的缓冲区指针
 * @retval 0: 读取成功
 * @retval 其他值: 读取失败的错误代码
 */
uint8_t MPU_Read_Len(uint8_t addr, uint8_t RegAddress, uint8_t count, uint8_t *DataBuffer) {
    uint8_t i;
    BSP_IIC_Start();
    BSP_IIC_Send_Byte((addr << 1) | 0); //发送器件地址+写命令
    if (BSP_IIC_Wait_Ack())          //等待应答
    {
        BSP_IIC_Stop();
        return 1;
    }
    BSP_IIC_Send_Byte(RegAddress);         //写寄存器地址
    BSP_IIC_Wait_Ack();             //等待应答

    BSP_IIC_Start();
    BSP_IIC_Send_Byte((addr << 1) | 1); //发送器件地址+读命令
    BSP_IIC_Wait_Ack();             //等待应答

    // 循环读取多个寄存器
    for (i = 0; i < count; i++) {
        DataBuffer[i] = BSP_IIC_Read_Byte();  // 接收寄存器数据

        // 除了最后一个字节外，都发送应答信号
        if (i < count - 1) {
            BSP_IIC_Ack();               // 发送应答，继续读取下一个字节
        } else {
            BSP_IIC_NAck();               // 发送非应答，终止读取
        }
    }
    BSP_IIC_Stop();                 //产生一个停止条件
    return 0;
}

//IIC写一个字节
//devaddr:器件IIC地址
//reg:寄存器地址
//data:数据
//返回值:0,正常
//    其他,错误代码
uint8_t MPU_Write_Byte(uint8_t addr, uint8_t reg, uint8_t data) {
    BSP_IIC_Start();
    BSP_IIC_Send_Byte((addr << 1) | 0); //发送器件地址+写命令
    if (BSP_IIC_Wait_Ack())          //等待应答
    {
        BSP_IIC_Stop();
        return 1;
    }
    BSP_IIC_Send_Byte(reg);         //写寄存器地址
    BSP_IIC_Wait_Ack();             //等待应答
    BSP_IIC_Send_Byte(data);        //发送数据
    if (BSP_IIC_Wait_Ack())          //等待ACK
    {
        BSP_IIC_Stop();
        return 1;
    }
    BSP_IIC_Stop();
    return 0;
}

//IIC读一个字节
//reg:寄存器地址
//返回值:读到的数据
uint8_t MPU_Read_Byte(uint8_t addr, uint8_t reg) {
    uint8_t res;
    BSP_IIC_Start();
    BSP_IIC_Send_Byte((addr << 1) | 0); //发送器件地址+写命令
    BSP_IIC_Wait_Ack();             //等待应答
    BSP_IIC_Send_Byte(reg);         //写寄存器地址
    BSP_IIC_Wait_Ack();             //等待应答

    BSP_IIC_Start();
    BSP_IIC_Send_Byte((addr << 1) | 1); //发送器件地址+读命令
    BSP_IIC_Wait_Ack();             //等待应答
    res = BSP_IIC_Read_Byte();            //读数据,发送nACK
    BSP_IIC_NAck();                  //不产生ACK应答
    BSP_IIC_Stop();                 //产生一个停止条件
    return res;
}


void Set_Acc_Gyro_Offset(void) {
    uint8_t i;
    int16_t ax_offset, ay_offset, az_offset, gx_offset, gy_offset, gz_offset;
    int32_t ax_offset_sum, ay_offset_sum, az_offset_sum, gx_offset_sum, gy_offset_sum, gz_offset_sum;
    int16_t gyro_off[3], acc_off[3];

    ax_offset_sum = 0;
    ay_offset_sum = 0;
    az_offset_sum = 0;
    gx_offset_sum = 0;
    gy_offset_sum = 0;
    gz_offset_sum = 0;

    for (i = 0; i < 20; i++) {
        MPU_Get_Gyroscope(gyro_off, gyro_off + 1, gyro_off + 2);
        MPU_Get_Accelerometer(acc_off, acc_off + 1, acc_off + 2);

        ax_offset = acc_off[0];
        ay_offset = acc_off[1];
        az_offset = acc_off[2];
        ax_offset_sum = ax_offset_sum + ax_offset;
        ay_offset_sum = ay_offset_sum + ay_offset;
        az_offset_sum = az_offset_sum + az_offset;

        gx_offset = gyro_off[0];
        gy_offset = gyro_off[1];
        gz_offset = gyro_off[2];
        gx_offset_sum = gx_offset_sum + gx_offset;
        gy_offset_sum = gy_offset_sum + gy_offset;
        gz_offset_sum = gz_offset_sum + gz_offset;
    }
    imu_9.acc_zero[0] = ax_offset_sum / 20;
    imu_9.acc_zero[1] = ay_offset_sum / 20;
    imu_9.acc_zero[2] = az_offset_sum / 20 - 16384;
    imu_9.gyro_zero[0] = gx_offset_sum / 20;
    imu_9.gyro_zero[1] = gy_offset_sum / 20;
    imu_9.gyro_zero[2] = gz_offset_sum / 20;

    //存入
//    STMFLASH_Write(ACC_ZERO_ADDR, (uint8_t *) &imu_9.acc_zero, 6);
//    STMFLASH_Write(GYRO_ZERO_ADDR, (uint8_t *) &imu_9.gyro_zero, 6);


}


/*校准过程
 * 一段时间内连续采集地磁xyz三个轴向上的最大值和最小值，做运算
 *
 */
void Set_Mag_Offset(void) {

    int16_t mag_x_max = 0, mag_x_min = 0;
    int16_t mag_y_max = 0, mag_y_min = 0;
    int16_t mag_z_max = 0, mag_z_min = 0;
    uint32_t cnt = 0;
    uint8_t r_data[6];
    int16_t mag_off[3];
    int16_t Xoffset, Yoffset, Zoffset;

    static float Xsf;
    static float Ysf;
    int16_t xsf_buf, ysf_buf;

    while (cnt < MAG_OFFSET_TIMES) {
        cnt++;
        MPU_Get_Gyroscope(mag_off, mag_off + 1, mag_off + 2);

        if (mag_off[0] < mag_x_min) mag_x_min = mag_off[0];
        else if (mag_off[0] > mag_x_max) mag_x_max = mag_off[0];


        if (mag_off[1] < mag_y_min) mag_y_min = mag_off[1];
        else if (mag_off[1] > mag_y_max) mag_y_max = mag_off[1];

        if (mag_off[2] < mag_z_min) mag_z_min = mag_off[2];
        else if (mag_off[2] > mag_z_max) mag_z_max = mag_off[2];

        HAL_Delay(1);
    }
    cnt = 0;

    Xsf = (mag_y_max - mag_y_min) / (mag_x_max - mag_x_min);
    Ysf = (mag_x_max - mag_x_min) / (mag_y_max - mag_y_min);

    if (Xsf < 1) {
        Xsf = 1;
    }

    if (Ysf < 1) {
        Ysf = 1;
    }

    Xoffset = ((mag_x_max - mag_x_min) / 2 - mag_x_max) * Xsf;
    Yoffset = ((mag_y_max - mag_y_min) / 2 - mag_y_max) * Ysf;
//    Zoffset = ( (mag_z_max-mag_z_min)/2 - mag_z_max) *Xsf;

    imu_9.mag_xsf = Xsf;
    imu_9.mag_ysf = Ysf;

    imu_9.mag_zero[0] = Xoffset;
    imu_9.mag_zero[1] = Yoffset;
//    imu_9.mag_zero[2] = Zoffset;
    imu_9.mag_zero[2] = 0.0f;

    xsf_buf = (uint16_t) (Xsf * 1000);
    ysf_buf = (uint16_t) (Ysf * 1000);

    //存入
//    STMFLASH_Write(MAG_ZERO_ADDR, (uint8_t *) &imu_9.mag_zero, 6);
//    STMFLASH_Write(MAG_OFFSET_XSF_ADDR, (uint8_t *) &xsf_buf, 2);
//    STMFLASH_Write(MAG_OFFSET_YSF_ADDR, (uint8_t *) &ysf_buf, 2);

}














///**
// * @brief  imu初始化
// * @author
// * @param  void
// * @return 0-成功 1-失败
// */
//uint8_t acc_gyro_init(void)
//{
//    uint8_t id = 0;
//    uint8_t cfg_index = 0;
//
//    BSP_I2C3_ReadReg(LSM6DS3_ADDR, WHO_AM_I, &id, 1);
//
//    for (cfg_index=0; cfg_index<sizeof(acc_gyro_init_reg)/sizeof(reg_cfg_t); cfg_index++)
//    {
//        if(acc_gyro_init_reg[cfg_index].reg==0&&acc_gyro_init_reg[cfg_index].dat==0)
//        {
//            continue;
//        }
//        BSP_I2C3_WriteReg(LSM6DS3_ADDR,acc_gyro_init_reg[cfg_index].reg, &acc_gyro_init_reg[cfg_index].dat,1);
//        HAL_Delay(1);
//
//    }
//
//    return id;
//}

///**
// * @brief  6轴采样
// * @author
// * @param  gyro-脱落仪数据 acc-加速度数据
// * @return void
// */
//void acc_gyro_sample_data(int16_t *gyro,int16_t *acc )
//{
//    uint8_t r_data[6];
//
//    BSP_I2C3_ReadReg(LSM6DS3_ADDR, ACCEL_XOUT_L, r_data, 6);
//
//    acc[0] = (int16_t)(r_data[0] + (r_data[1] << 8));
//    acc[1] = (int16_t)(r_data[2] + (r_data[3] << 8));
//    acc[2] = (int16_t)(r_data[4] + (r_data[5] << 8));
//
//    BSP_I2C3_ReadReg(LSM6DS3_ADDR, GYRO_XOUT_L, r_data, 6);
//    gyro[0] = (int16_t)(r_data[0] + (r_data[1] << 8));
//    gyro[1] = (int16_t)(r_data[2] + (r_data[3] << 8));
//    gyro[2] = (int16_t)(r_data[4] + (r_data[5] << 8));
//
//
//
//}


//void set_acc_gyro_offset(void)
//{
//    uint8_t i;
//    int16_t ax_offset, ay_offset, az_offset, gx_offset, gy_offset, gz_offset;
//    int32_t ax_offset_sum, ay_offset_sum, az_offset_sum, gx_offset_sum, gy_offset_sum, gz_offset_sum;
//    int16_t gyro_off[3],acc_off[3];
//
//    ax_offset_sum = 0;
//    ay_offset_sum = 0;
//    az_offset_sum = 0;
//    gx_offset_sum = 0;
//    gy_offset_sum = 0;
//    gz_offset_sum = 0;
//
//    for (i = 0; i < 20; i++)
//    {
//        acc_gyro_sample_data(gyro_off,acc_off);
//
//        ax_offset = acc_off[0];
//        ay_offset = acc_off[1];
//        az_offset = acc_off[2];
//        ax_offset_sum = ax_offset_sum + ax_offset;
//        ay_offset_sum = ay_offset_sum + ay_offset;
//        az_offset_sum = az_offset_sum + az_offset;
//
//        gx_offset = gyro_off[0];
//        gy_offset = gyro_off[1];
//        gz_offset = gyro_off[2];
//        gx_offset_sum = gx_offset_sum + gx_offset;
//        gy_offset_sum = gy_offset_sum + gy_offset;
//        gz_offset_sum = gz_offset_sum + gz_offset;
//    }
//    imu_9.acc_zero[0] = ax_offset_sum/20;
//    imu_9.acc_zero[1] = ay_offset_sum/20;
//    imu_9.acc_zero[2] = az_offset_sum/20 - 16384;
//    imu_9.gyro_zero[0] = gx_offset_sum/20;
//    imu_9.gyro_zero[1] = gy_offset_sum/20;
//    imu_9.gyro_zero[2] = gz_offset_sum/20;
//
//    //存入
//    STMFLASH_Write(ACC_ZERO_ADDR,(uint8_t*)&imu_9.acc_zero,6);
//    STMFLASH_Write(GYRO_ZERO_ADDR,(uint8_t*)&imu_9.gyro_zero,6);
//
//
//
//
//
//}
