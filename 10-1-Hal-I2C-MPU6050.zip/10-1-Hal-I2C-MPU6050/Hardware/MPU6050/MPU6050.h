#ifndef __MPU6050_H
#define __MPU6050_H



typedef struct{
    // 角速度
    float Accel_X;
    float Accel_Y;
    float Accel_Z;
    // 角度
    float Gyro_X;
    float Gyro_Y;
    float Gyro_Z;
    // 温度
    float Temp;
}MPU6050_Data_t;





extern MPU6050_Data_t Mpu6050_Data;


void MPU6050_WriteReg(uint8_t RegAddress, uint8_t Data);
uint8_t MPU6050_ReadReg(uint8_t RegAddress);

void MPU6050_Init(void);
uint8_t MPU6050_GetID(void);



void MPU6050_ReadReg_All(uint8_t RegAddress, uint8_t count, uint8_t *DataBuffer);
void MPU6050_GetData_All(MPU6050_Data_t *Data);




/*下面的函数弃用hg*/
void MPU6050_GetData(int16_t *AccX, int16_t *AccY, int16_t *AccZ,
                     int16_t *GyroX, int16_t *GyroY, int16_t *GyroZ);



#endif
